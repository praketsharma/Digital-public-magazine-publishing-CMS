-- Digital Magazine Publishing CMS
-- complete_setup.sql
-- This file combines all setup scripts into one file
-- Run this to set up the entire CMS at once

-- ============================================================================
-- PART 1: SCHEMA CREATION
-- ============================================================================

-- Create the database
CREATE DATABASE IF NOT EXISTS magazine_cms;
USE magazine_cms;

-- Drop tables in reverse order to avoid foreign key issues
DROP TABLE IF EXISTS audit_log;
DROP TABLE IF EXISTS comments;
DROP TABLE IF EXISTS stats;
DROP TABLE IF EXISTS media;
DROP TABLE IF EXISTS article_tags;
DROP TABLE IF EXISTS article_authors;
DROP TABLE IF EXISTS articles;
DROP TABLE IF EXISTS magazines;
DROP TABLE IF EXISTS tags;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS authors;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS roles;

-- 1. Create roles table
CREATE TABLE roles (
    role_id INT AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(50) NOT NULL UNIQUE COMMENT 'admin, editor, author, viewer'
);

-- 2. Create users table
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL COMMENT 'in real app, this would be hashed',
    role_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES roles(role_id) ON DELETE SET NULL
);

-- 3. Create authors table
CREATE TABLE authors (
    author_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    bio TEXT
);

-- 4. Create categories table
CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT
);

-- 5. Create tags table
CREATE TABLE tags (
    tag_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE
);

-- 6. Create magazines table
CREATE TABLE magazines (
    magazine_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    issue_number VARCHAR(50) NOT NULL,
    publication_date DATE,
    status ENUM('draft', 'published', 'archived') NOT NULL DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(title, issue_number)
);

-- 7. Create articles table
CREATE TABLE articles (
    article_id INT AUTO_INCREMENT PRIMARY KEY,
    magazine_id INT,
    category_id INT,
    title VARCHAR(255) NOT NULL,
    content LONGTEXT,
    status ENUM('draft', 'under_review', 'published', 'archived') NOT NULL DEFAULT 'draft',
    publication_date DATE,
    scheduled_for DATETIME COMMENT 'for future publishing',
    created_by_user_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (magazine_id) REFERENCES magazines(magazine_id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE SET NULL,
    FOREIGN KEY (created_by_user_id) REFERENCES users(user_id) ON DELETE SET NULL,
    FULLTEXT(title, content) COMMENT 'for full-text search'
);

-- 8. Create article_authors junction table
CREATE TABLE article_authors (
    article_id INT,
    author_id INT,
    PRIMARY KEY (article_id, author_id),
    FOREIGN KEY (article_id) REFERENCES articles(article_id) ON DELETE CASCADE,
    FOREIGN KEY (author_id) REFERENCES authors(author_id) ON DELETE CASCADE
);

-- 9. Create article_tags junction table
CREATE TABLE article_tags (
    article_id INT,
    tag_id INT,
    PRIMARY KEY (article_id, tag_id),
    FOREIGN KEY (article_id) REFERENCES articles(article_id) ON DELETE CASCADE,
    FOREIGN KEY (tag_id) REFERENCES tags(tag_id) ON DELETE CASCADE
);

-- 10. Create media table
CREATE TABLE media (
    media_id INT AUTO_INCREMENT PRIMARY KEY,
    article_id INT,
    media_type ENUM('image', 'video', 'pdf') NOT NULL,
    media_url VARCHAR(2048) NOT NULL,
    caption VARCHAR(255),
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (article_id) REFERENCES articles(article_id) ON DELETE CASCADE
);

-- 11. Create comments table
CREATE TABLE comments (
    comment_id INT AUTO_INCREMENT PRIMARY KEY,
    article_id INT NOT NULL,
    user_id INT,
    content TEXT NOT NULL,
    is_approved BOOLEAN NOT NULL DEFAULT FALSE COMMENT 'moderation flag',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (article_id) REFERENCES articles(article_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
);

-- 12. Create stats table for tracking views and downloads
CREATE TABLE stats (
    article_id INT PRIMARY KEY,
    view_count INT DEFAULT 0,
    download_count INT DEFAULT 0,
    FOREIGN KEY (article_id) REFERENCES articles(article_id) ON DELETE CASCADE
);

-- 13. Create audit_log table for tracking changes
CREATE TABLE audit_log (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    table_name VARCHAR(50) NOT NULL COMMENT 'which table was changed',
    action VARCHAR(20) NOT NULL COMMENT 'INSERT, UPDATE, DELETE',
    record_id INT NOT NULL COMMENT 'ID of the record that changed',
    user_id INT COMMENT 'who made the change',
    old_data JSON COMMENT 'data before change',
    new_data JSON COMMENT 'data after change',
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
);

-- Create indexes for better performance
CREATE INDEX idx_articles_status ON articles(status);
CREATE INDEX idx_articles_publication_date ON articles(publication_date);
CREATE INDEX idx_magazines_status ON magazines(status);
CREATE INDEX idx_audit_log_timestamp ON audit_log(timestamp);

-- ============================================================================
-- PART 2: SAMPLE DATA
-- ============================================================================

-- 1. Add roles
INSERT INTO roles (role_name) VALUES
('admin'),
('editor'),
('author'),
('viewer');

-- 2. Add users
INSERT INTO users (username, email, password, role_id) VALUES
('admin', 'admin@magazine.com', 'admin123', 1),
('editor1', 'editor@magazine.com', 'editor123', 2),
('author1', 'author1@magazine.com', 'author123', 3),
('author2', 'author2@magazine.com', 'author456', 3),
('viewer1', 'viewer@magazine.com', 'viewer123', 4);

-- 3. Add authors
INSERT INTO authors (name, email, bio) VALUES
('John Smith', 'john@example.com', 'Technology writer with 10 years experience'),
('Sarah Johnson', 'sarah@example.com', 'Travel and lifestyle journalist'),
('Mike Brown', 'mike@example.com', 'Science and health expert');

-- 4. Add categories
INSERT INTO categories (name, description) VALUES
('Technology', 'Latest tech news and reviews'),
('Travel', 'Travel guides and destination stories'),
('Health', 'Health tips and wellness advice'),
('Science', 'Scientific discoveries and research');

-- 5. Add tags
INSERT INTO tags (name) VALUES
('AI'),
('Programming'),
('Travel Tips'),
('Fitness'),
('Space'),
('Mental Health');

-- 6. Add magazines
INSERT INTO magazines (title, issue_number, publication_date, status) VALUES
('Tech Weekly', 'Issue 1', '2023-10-01', 'published'),
('Travel Guide', 'Spring 2023', '2023-03-15', 'published'),
('Health Today', 'Vol 2', '2023-11-01', 'published'),
('Science Monthly', 'December 2023', NULL, 'draft');

-- 7. Add articles
INSERT INTO articles (magazine_id, category_id, title, content, status, publication_date, created_by_user_id) VALUES
(1, 1, 'The Future of AI', 'Artificial Intelligence is changing the world...', 'published', '2023-10-01', 3),
(2, 2, 'Best Travel Destinations', 'Here are the top 10 places to visit...', 'published', '2023-03-15', 4),
(1, 1, 'Learning Python', 'A beginner guide to Python programming...', 'under_review', NULL, 3),
(3, 4, 'Mental Health Tips', 'Simple ways to improve your mental health...', 'published', '2023-11-01', 4),
(1, 1, 'Web Development Basics', 'HTML, CSS, and JavaScript fundamentals...', 'draft', NULL, 3);

-- 8. Link articles to authors
INSERT INTO article_authors (article_id, author_id) VALUES
(1, 1),
(2, 2),
(3, 1),
(4, 3),
(5, 1);

-- 9. Add tags to articles
INSERT INTO article_tags (article_id, tag_id) VALUES
(1, 1),
(2, 3),
(3, 2),
(4, 6),
(5, 2);

-- 10. Add media files
INSERT INTO media (article_id, media_type, media_url, caption) VALUES
(1, 'image', 'https://example.com/ai-future.jpg', 'AI technology illustration'),
(2, 'image', 'https://example.com/travel-destinations.jpg', 'Beautiful travel destinations'),
(4, 'pdf', 'https://example.com/health-guide.pdf', 'Complete health guide');

-- 11. Add comments
INSERT INTO comments (article_id, user_id, content, is_approved) VALUES
(1, 5, 'Great article! Very informative.', TRUE),
(1, 2, 'I learned a lot from this. Thanks!', TRUE),
(2, 5, 'I want to visit these places!', FALSE);

-- 12. Add statistics
INSERT INTO stats (article_id, view_count, download_count) VALUES
(1, 1500, 200),
(2, 2200, 150),
(4, 800, 50);

-- ============================================================================
-- PART 3: PROCEDURES, TRIGGERS, AND VIEWS
-- ============================================================================

-- -----------------------------------------------------------------------------
-- Stored Procedures
-- -----------------------------------------------------------------------------

-- Procedure to add a new magazine
DELIMITER $$
CREATE PROCEDURE add_magazine(
    IN p_title VARCHAR(255),
    IN p_issue_number VARCHAR(50),
    IN p_publication_date DATE,
    IN p_status VARCHAR(20)
)
BEGIN
    INSERT INTO magazines (title, issue_number, publication_date, status)
    VALUES (p_title, p_issue_number, p_publication_date, p_status);
    
    SELECT 'Magazine added successfully!' AS message;
END$$
DELIMITER ;

-- Procedure to add a new article
DELIMITER $$
CREATE PROCEDURE add_article(
    IN p_magazine_id INT,
    IN p_category_id INT,
    IN p_title VARCHAR(255),
    IN p_content TEXT,
    IN p_author_id INT,
    IN p_user_id INT
)
BEGIN
    DECLARE new_article_id INT;
    
    -- Insert the article
    INSERT INTO articles (magazine_id, category_id, title, content, created_by_user_id)
    VALUES (p_magazine_id, p_category_id, p_title, p_content, p_user_id);
    
    SET new_article_id = LAST_INSERT_ID();
    
    -- Link the author
    INSERT INTO article_authors (article_id, author_id)
    VALUES (new_article_id, p_author_id);
    
    SELECT CONCAT('Article added with ID: ', new_article_id) AS message;
END$$
DELIMITER ;

-- Procedure to publish an article
DELIMITER $$
CREATE PROCEDURE publish_article(IN p_article_id INT)
BEGIN
    UPDATE articles 
    SET status = 'published', publication_date = CURDATE()
    WHERE article_id = p_article_id;
    
    SELECT 'Article published successfully!' AS message;
END$$
DELIMITER ;

-- Procedure to add a comment
DELIMITER $$
CREATE PROCEDURE add_comment(
    IN p_article_id INT,
    IN p_user_id INT,
    IN p_content TEXT
)
BEGIN
    INSERT INTO comments (article_id, user_id, content)
    VALUES (p_article_id, p_user_id, p_content);
    
    SELECT 'Comment added successfully!' AS message;
END$$
DELIMITER ;

-- Procedure to approve a comment
DELIMITER $$
CREATE PROCEDURE approve_comment(IN p_comment_id INT)
BEGIN
    UPDATE comments 
    SET is_approved = TRUE
    WHERE comment_id = p_comment_id;
    
    SELECT 'Comment approved!' AS message;
END$$
DELIMITER ;

-- Procedure to record a view
DELIMITER $$
CREATE PROCEDURE record_view(IN p_article_id INT)
BEGIN
    UPDATE stats 
    SET view_count = view_count + 1
    WHERE article_id = p_article_id;
    
    -- If no stats record exists, create one
    IF ROW_COUNT() = 0 THEN
        INSERT INTO stats (article_id, view_count) VALUES (p_article_id, 1);
    END IF;
END$$
DELIMITER ;

-- -----------------------------------------------------------------------------
-- Triggers
-- -----------------------------------------------------------------------------

-- Trigger to create stats record when article is created
DELIMITER $$
CREATE TRIGGER after_article_insert
AFTER INSERT ON articles
FOR EACH ROW
BEGIN
    INSERT INTO stats (article_id, view_count, download_count)
    VALUES (NEW.article_id, 0, 0);
END$$
DELIMITER ;

-- Trigger to log magazine changes
DELIMITER $$
CREATE TRIGGER after_magazine_insert
AFTER INSERT ON magazines
FOR EACH ROW
BEGIN
    INSERT INTO audit_log (table_name, action, record_id, old_data, new_data)
    VALUES ('magazines', 'INSERT', NEW.magazine_id, NULL, 
            JSON_OBJECT('title', NEW.title, 'status', NEW.status));
END$$
DELIMITER ;

DELIMITER $$
CREATE TRIGGER after_magazine_update
AFTER UPDATE ON magazines
FOR EACH ROW
BEGIN
    INSERT INTO audit_log (table_name, action, record_id, old_data, new_data)
    VALUES ('magazines', 'UPDATE', NEW.magazine_id,
            JSON_OBJECT('title', OLD.title, 'status', OLD.status),
            JSON_OBJECT('title', NEW.title, 'status', NEW.status));
END$$
DELIMITER ;

-- Trigger to log article changes
DELIMITER $$
CREATE TRIGGER after_article_insert_log
AFTER INSERT ON articles
FOR EACH ROW
BEGIN
    INSERT INTO audit_log (table_name, action, record_id, old_data, new_data)
    VALUES ('articles', 'INSERT', NEW.article_id, NULL,
            JSON_OBJECT('title', NEW.title, 'status', NEW.status));
END$$
DELIMITER ;

DELIMITER $$
CREATE TRIGGER after_article_update_log
AFTER UPDATE ON articles
FOR EACH ROW
BEGIN
    INSERT INTO audit_log (table_name, action, record_id, old_data, new_data)
    VALUES ('articles', 'UPDATE', NEW.article_id,
            JSON_OBJECT('title', OLD.title, 'status', OLD.status),
            JSON_OBJECT('title', NEW.title, 'status', NEW.status));
END$$
DELIMITER ;

-- -----------------------------------------------------------------------------
-- Views
-- -----------------------------------------------------------------------------

-- View for published articles (for viewers)
CREATE VIEW published_articles AS
SELECT 
    a.article_id,
    a.title,
    a.content,
    a.publication_date,
    m.title AS magazine_title,
    c.name AS category,
    GROUP_CONCAT(DISTINCT auth.name SEPARATOR ', ') AS authors,
    s.view_count
FROM articles a
JOIN magazines m ON a.magazine_id = m.magazine_id
LEFT JOIN categories c ON a.category_id = c.category_id
LEFT JOIN article_authors aa ON a.article_id = aa.article_id
LEFT JOIN authors auth ON aa.author_id = auth.author_id
LEFT JOIN stats s ON a.article_id = s.article_id
WHERE a.status = 'published'
GROUP BY a.article_id;

-- View for articles under review (for editors)
CREATE VIEW articles_for_review AS
SELECT 
    a.article_id,
    a.title,
    a.created_at,
    u.username AS created_by,
    c.name AS category
FROM articles a
JOIN users u ON a.created_by_user_id = u.user_id
LEFT JOIN categories c ON a.category_id = c.category_id
WHERE a.status = 'under_review';

-- View for author's articles
CREATE VIEW author_articles AS
SELECT 
    auth.name AS author_name,
    a.title,
    a.status,
    a.publication_date,
    s.view_count
FROM articles a
JOIN article_authors aa ON a.article_id = aa.article_id
JOIN authors auth ON aa.author_id = auth.author_id
LEFT JOIN stats s ON a.article_id = s.article_id;

-- View for approved comments
CREATE VIEW approved_comments AS
SELECT 
    c.comment_id,
    a.title AS article_title,
    u.username,
    c.content,
    c.created_at
FROM comments c
JOIN articles a ON c.article_id = a.article_id
LEFT JOIN users u ON c.user_id = u.user_id
WHERE c.is_approved = TRUE;

-- View for audit log (for admins)
CREATE VIEW recent_changes AS
SELECT 
    table_name,
    action,
    record_id,
    timestamp,
    old_data,
    new_data
FROM audit_log
ORDER BY timestamp DESC
LIMIT 50;

-- -----------------------------------------------------------------------------
-- Event for scheduled publishing
-- -----------------------------------------------------------------------------

-- Create event to publish scheduled articles
DELIMITER $$
CREATE EVENT publish_scheduled_articles
ON SCHEDULE EVERY 1 HOUR
DO
BEGIN
    UPDATE articles 
    SET status = 'published', publication_date = CURDATE()
    WHERE scheduled_for IS NOT NULL 
      AND scheduled_for <= NOW() 
      AND status != 'published';
END$$
DELIMITER ;

-- ============================================================================
-- SETUP COMPLETE!
-- ============================================================================

SELECT 'Digital Magazine CMS setup complete!' AS message;
SELECT 'Database: magazine_cms' AS info;
SELECT 'Tables created: 13' AS info;
SELECT 'Sample data added' AS info;
SELECT 'Procedures, triggers, and views created' AS info;

-- Enable event scheduler for scheduled publishing
SET GLOBAL event_scheduler = ON;
SELECT 'Event scheduler enabled' AS info;

-- Show some sample data to verify setup
SELECT 'Sample published articles:' AS info;
SELECT title, magazine_title, category FROM published_articles LIMIT 3; 