# Digital Magazine Publishing CMS CREATED BY PRAKET SHARMA.

# This is a complete MySQL-based Content Management System for digital magazines. 
# This project demonstrates a full-featured CMS using only SQL with no front-end or back-end code.

This system manages:-
**Magazines** with issues and publication dates
**Articles** with authors, categories, and tags
**Media files** (images, videos, PDFs) linked to articles
**User roles** (admin, editor, author, viewer)
**Comments** with moderation
**Statistics** tracking views and downloads
**Scheduled publishing** for future articles
**Audit trail** for all changes
=======================================================================================================

### Prerequisites:-
- MySQL 8.0 or later
- Basic knowledge of SQL
=======================================================================================================
### Setup Steps:-

1. **Open MySQL command line or workbench**
   ```sql
   mysql -u your_username -p
   ```

2. **Run the schema script**
   ```sql
   SOURCE schema.sql;
   ```

3. **Add sample data**
   ```sql
   SOURCE sample_data.sql;
   ```

4. **Create procedures and views**
   ```sql
   SOURCE procedures_triggers_views.sql;
   ```

5. **Enable event scheduler** (for scheduled publishing)
   ```sql
   SET GLOBAL event_scheduler = ON;
   ```
=======================================================================================================
## Testing the Features:-

### 1. View Published Articles
```sql
SELECT * FROM published_articles;
```

### 2. Add a New Magazine
```sql
CALL add_magazine('Tech News', 'Issue 5', '2024-01-15', 'draft');
```

### 3. Add a New Article
```sql
CALL add_article(1, 1, 'New AI Breakthrough', 'This is the content...', 1, 3);
```

### 4. Publish an Article
```sql
CALL publish_article(3);
```

### 5. Add a Comment
```sql
CALL add_comment(1, 5, 'Great article!');
```

### 6. Approve a Comment
```sql
CALL approve_comment(3);
```

### 7. Record a View
```sql
CALL record_view(1);
```

### 8. Full-Text Search
```sql
SELECT * FROM articles 
WHERE MATCH(title, content) AGAINST('AI' IN NATURAL LANGUAGE MODE);
```

### 9. View Articles Under Review (Editor Dashboard)
```sql
SELECT * FROM articles_for_review;
```

### 10. View Author's Articles
```sql
SELECT * FROM author_articles WHERE author_name = 'John Smith';
```

### 11. View Recent Changes (Admin Dashboard)
```sql
SELECT * FROM recent_changes;
```

### 12. View Approved Comments
```sql
SELECT * FROM approved_comments;
```
=======================================================================================================
## Database Structure:-

### Core Tables:-
- `roles` - User roles (admin, editor, author, viewer)
- `users` - System users with passwords and roles
- `authors` - Article authors with bios
- `categories` - Article categories
- `tags` - Article tags
- `magazines` - Magazine issues
- `articles` - Articles with content and status
- `media` - Images, videos, PDFs linked to articles

### Junction Tables:-
- `article_authors` - Links articles to authors (many-to-many)
- `article_tags` - Links articles to tags (many-to-many)

### Supporting Tables:-
- `comments` - Reader comments with moderation
- `stats` - View and download counts
- `audit_log` - Tracks all changes for security
=======================================================================================================
## Key Features Explained:-

### Publication Workflow
1. **Draft** - Article is being written
2. **Under Review** - Editor is reviewing
3. **Published** - Live on the website
4. **Archived** - No longer active

### User Roles
- **Admin** - Full access, can view audit logs
- **Editor** - Can review and publish articles
- **Author** - Can create articles
- **Viewer** - Can read published content and comment

### Automated Features
- **Triggers** automatically create stats records for new articles
- **Triggers** log all changes to the audit trail
- **Event** publishes scheduled articles every hour
- **Views** provide role-based access to data
=======================================================================================================
##  Common Queries:-

### Find Articles by Category
```sql
SELECT a.title, c.name as category 
FROM articles a 
JOIN categories c ON a.category_id = c.category_id 
WHERE c.name = 'Technology';
```

### Find Articles by Author
```sql
SELECT a.title, auth.name as author 
FROM articles a 
JOIN article_authors aa ON a.article_id = aa.article_id 
JOIN authors auth ON aa.author_id = auth.author_id 
WHERE auth.name = 'John Smith';
```

### Find Articles by Tag
```sql
SELECT a.title, t.name as tag 
FROM articles a 
JOIN article_tags at ON a.article_id = at.article_id 
JOIN tags t ON at.tag_id = t.tag_id 
WHERE t.name = 'AI';
```

### Get Article Statistics
```sql
SELECT a.title, s.view_count, s.download_count 
FROM articles a 
JOIN stats s ON a.article_id = s.article_id 
ORDER BY s.view_count DESC;
```
=======================================================================================================
##  Troubleshooting

### Common Issues

1. **"Event scheduler is disabled"**
   ```sql
   SET GLOBAL event_scheduler = ON;
   ```

2. **"Foreign key constraint fails"**
   - Make sure to run scripts in order: schema → sample_data → procedures_triggers_views

3. **"Full-text search not working"**
   - Make sure you're using MySQL 8.0+ and the FULLTEXT index is created

### Reset Database
```sql
DROP DATABASE magazine_cms;
-- Then run all scripts again
```
///////////////////////////////////////////////////////////////////////////////////////////////////////
## what more we could do:-

This CMS is designed to be easily extendable. You could add:
- Email notifications for new articles
- RSS feeds for published content
- More detailed analytics
- User subscriptions
- Payment processing for premium content

##  Learning Resources

- [MySQL Documentation](https://dev.mysql.com/doc/)
- [MySQL Stored Procedures](https://dev.mysql.com/doc/refman/8.0/en/stored-programs-defining.html)
- [MySQL Triggers](https://dev.mysql.com/doc/refman/8.0/en/triggers.html)
- [MySQL Views](https://dev.mysql.com/doc/refman/8.0/en/views.html)

---

**THE END** 